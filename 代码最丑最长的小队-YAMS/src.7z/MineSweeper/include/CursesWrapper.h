#ifndef MINESWEEPER_CURSESWRAPPER_H
#define MINESWEEPER_CURSESWRAPPER_H

#include <curses.h>

#endif

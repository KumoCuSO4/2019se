/*
 * This file contains some utilities used by the game.
 */
#ifndef MINESWEEPER_GAME_H
#define MINESWEEPER_GAME_H

void game_run();

#endif

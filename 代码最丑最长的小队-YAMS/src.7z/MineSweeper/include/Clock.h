#ifndef MINESWEEPER_CLOCK_H
#define MINESWEEPER_CLOCK_H
#include "Tui.h"

// args: Position upper_left
void *clock_start(void *args);
int clock_end();

#endif

#include <ctype.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>
#include <stdio.h>
#include <windows.h>
char upper[32*24][2];//你能看见的东西
char change(char a){
	if(a=='0')
		return ' ';
	if(a=='9')
		return '#';
	return a;
}
int sf(char b[],unsigned c,unsigned d,unsigned e);
void zhankai(char b[],unsigned c,unsigned d);
int sf(char b[],unsigned c,unsigned d,unsigned e){
	int val=0;
	int ll=0;
	for(int i=0; i<d; ++i) {
		for(int v=0; v<c; ++v) {
			if(upper[i*c+v][1]=='#'){
				for(int y=0;y<d;++y){
					for(int x=0;x<c;++x){
						if(b[y*c+x]=='9'){
							upper[y*c+x][0]='o';
							upper[y*c+x][1]='#';
						}
					}
				}
				return -1;
			}
			if(upper[i*c+v][1]=='s') {
				if(upper[i*c+v][1]=='s'&&b[i*c+v]=='9')
					++ll;
				++val;
				if(ll==e&&val==ll){
					return 1;
				}
			}
		}
	}
	int valll=0;
	for(int i=0; i<c*d; ++i)
		if(upper[i][0]!='c'&&upper[i][0]!='s')
			++valll;
	if(valll>=(c*d-e)){
		return 1;
	}
	return 0;
}
void zhankai(char b[],unsigned c,unsigned d){
	int aaa=1;
	while(aaa) {
		int vall=0;
		for(int i=0; i<d;) {
			for(int v=0; v<c; ++v) {
				if(upper[i*c+v] [1]==' ') {
					if(i>=1)
						if(upper[(i-1)*c+v] [0]=='c') {
							upper[(i-1)*c+v] [0]='o';
							upper[(i-1)*c+v] [1]= change(b[(i-1)*c+v]);
							++vall;
						}
					if(v>=1)
						if(upper[i*c+v-1] [0]=='c') {
							upper[i*c+v-1] [0]='o';
							upper[i*c+v-1] [1]=change(b[i*c+v-1]);
							++vall;
						}
					if(v>=1&&i>=1)
						if(upper[(i-1)*c+v-1] [0]=='c') {
							upper[(i-1)*c+v-1] [0]='o';
							upper[(i-1)*c+v-1] [1]=change(b[(i-1)*c+v-1]);
							++vall;
						}
					if(i>=1&&v<(c-1))
						if(upper[(i-1)*c+v+1] [0]=='c') {
							upper[(i-1)*c+v+1] [0]='o';
							upper[(i-1)*c+v+1] [1]=change(b[(i-1)*c+v+1]);
							++vall;
						}
					if(i<(d-1)&&v>=1)
						if(upper[(i+1)*c+v-1] [0]=='c') {
							upper[(i+1)*c+v-1] [0]='o';
							upper[(i+1)*c+v-1] [1]=change(b[(i+1)*c+v-1]);
							++vall;
						}
					if(i<(d-1))
						if(upper[(i+1)*c+v] [0]=='c') {
							upper[(i+1)*c+v] [0]='o';
							upper[(i+1)*c+v] [1]=change(b[(i+1)*c+v]);
							++vall;
						}
					if(v<(c-1))
						if(upper[i*c+v+1] [0]=='c') {
							upper[i*c+v+1] [0]='o';
							upper[i*c+v+1] [1]=change(b[i*c+v+1]);
							++vall;
						}
					if(i<(d-1)&&v<(c-1))
						if(upper[(i+1)*c+v+1] [0]=='c') {
							upper[(i+1)*c+v+1] [0]='o';
							upper[(i+1)*c+v+1] [1]=change(b[(i+1)*c+v+1]);
							++vall;
						}
				}
			}
			++i;
		}
		if(vall==0)
			aaa=0;
	}
	return;
}
int main(){
    srand((unsigned)time(NULL));
    unsigned xll=0,yll=0,temp=1;
    unsigned  x=0, y=0;
    unsigned length=10,width=10,boom_count=10;
    int lose=1;
    scanf("%d%d%d",&length,&width,&boom_count);
    if(length<10)
		length=10;
	if(width<10)
		width=10;
	if(length>32)
		length=32;
	if(width>24)
		width=24;
	if(boom_count>90)
		boom_count=90;
	if(boom_count<10)
		boom_count=10;
    char under[length*width];//存数字
    for(int i=0;i<length*width;++i){
        upper[i][0]='c';
        upper[i][1]='+';
        under[i]='0';
    }
    //先进行第一次输入
    while(temp){
        system("cls");
        for(int i=0; i<width; ++i) {
			for(int v=0; v<length; ++v) {
                if(v==x&&i==y)
                    printf("*");
                else
				    printf("%c",upper[i*length+v][1]);
			}
            printf("\n");
		}
        char ch;
        if(kbhit()){
            ch=getch();
            switch(ch){
                case 'w':
                if(y>0)
                    --y;
                break;
                case 's':
                if(y<width-1)
                    ++y;
                break;
                case 'a':
                if(x>0)
                    --x;
                break;
                case 'd':
                if(x<length-1)
                    ++x;
                break;
                case 'j':
                    xll=x;
                    yll=y;
                    temp=0;
                break;
            }
        }
        Sleep(50);
    }
    //生成雷
    while(1) {
		int x1,y1;
		x1=rand()%length;
		y1=rand()%width;
		if(x1==xll&&y1==yll)
			continue;
		if(under[length*y1+x1]=='0') {
			under[length*y1+x1]='9';//用‘9’表示雷
			++temp;
		}
		if(temp==boom_count)
			break;
	}
    //生成实际数字分布
    for(int i=0; i<width; ++i) {
		for(int v=0; v<length; ++v) {
			if(under[i*length+v]!='9') {
				if(i>=1)
					if(under[(i-1)*length+v]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
				if(v>=1)
					if(under[i*length+v-1]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
				if(v>=1&&i>=1)
					if(under[(i-1)*length+v-1]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
				if(i>=1&&v<(length-1))
					if(under[(i-1)*length+v+1]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
				if(i<(width-1)&&v>=1)
					if(under[(i+1)*length+v-1]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
				if(i<(width-1))
					if(under[(i+1)*length+v]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
				if(v<(length-1))
					if(under[i*length+v+1]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
				if(i<(width-1)&&v<(length-1))
					if(under[(i+1)*length+v+1]=='9')
						under[i*length+v]=(char)(1+(int)under[i*length+v]);
			}
		}
	}
	upper[yll*length+xll][0]='o';
	upper[yll*length+xll][1]=change(under[yll*length+xll]);
    //game start!!!
    while(1) {
        system("cls");
		for(int i=0; i<width; ++i) {
			for(int v=0; v<length; ++v) {
                if(v==x&&i==y)
                    printf("*");
                else
				    printf("%c",upper[i*length+v][1]);
			}
            printf("\n");
		}
		if(kbhit()&&lose) {
            char ch=getch();
			switch(ch) {
			case 'w':
				if(y>0)
					--y;
				break;
			case 's':
				if(y+1<width)
					++y;
				break;
			case 'a':
					if(x>0)
						--x;
				break;
			case 'd':
					if(x+1<length)
						++x;
				break;
			case 'j':
				if(upper[y*length+x][0]=='o') {
					char able='0';
					if(y>=1)
						if(upper[(y-1)*length+x][0]=='s')
							++able;
					if(x>=1)
						if(upper[y*length+x-1][0]=='s')
							++able;
					if(x>=1&&y>=1)
						if(upper[(y-1)*length+x-1][0]=='s')
							++able;
					if(y>=1&&x<(length-1))
						if(upper[(y-1)*length+x+1][0]=='s')
							++able;
					if(y<(width-1)&&x>=1)
						if(upper[(y+1)*length+x-1][0]=='s')
							++able;
					if(y<(width-1))
						if(upper[(y+1)*length+x][0]=='s')
							++able;
					if(x<(length-1))
						if(upper[y*length+x+1][0]=='s')
							++able;
					if(y<(width-1)&&x<(length-1))
						if(upper[(y+1)*length+x+1][0]=='s')
							++able;
					if(able==under[y*length+x]) {
						if(y>=1)
							if(upper[(y-1)*length+x][0]=='c') {
								upper[(y-1)*length+x][0]='o';
								upper[(y-1)*length+x][1]=change(under[(y-1)*length+x]);
							}
						if(x>=1)
							if(upper[y*length+x-1][0]=='c') {
								upper[y*length+x-1][0]='o';
								upper[y*length+x-1][1]=change(under[y*length+x-1]);
							}
						if(x>=1&&y>=1)
							if(upper[(y-1)*length+x-1][0]=='c') {
								upper[(y-1)*length+x-1][0]='o';
								upper[(y-1)*length+x-1][1]=change(under[(y-1)*length+x-1]);
							}
						if(y>=1&&x<(length-1))
							if(upper[(y-1)*length+x+1][0]=='c') {
								upper[(y-1)*length+x+1][0]='o';
								upper[(y-1)*length+x+1][1]=change(under[(y-1)*length+x+1]);
							}
						if(y<(width-1)&&x>=1)
							if(upper[(y+1)*length+x-1][0]=='c') {
								upper[(y+1)*length+x-1][0]='o';
								upper[(y+1)*length+x-1][1]=change(under[(y+1)*length+x-1]);
							}
						if(y<(width-1))
							if(upper[(y+1)*length+x][0]=='c') {
								upper[(y+1)*length+x][0]='o';
								upper[(y+1)*length+x][1]=change(under[(y+1)*length+x]);
							}
						if(x<(length-1))
							if(upper[y*length+x+1][0]=='c') {
								upper[y*length+x+1][0]='o';
								upper[y*length+x+1][1]=change(under[y*length+x+1]);
							}
						if(y<(width-1)&&x<(length-1))
							if(upper[(y+1)*length+x+1][0]=='c') {
								upper[(y+1)*length+x+1][0]='o';
								upper[(y+1)*length+x+1][1]=change(under[(y+1)*length+x+1]);
							}
						zhankai(under,length,width);
					}
				}
				if(upper[y*length+x][0]=='c')
					upper[y*length+x][0]='o';
				break;
			case 'k':
				if(upper[y*length+x][1]=='s')
					upper[y*length+x][0]='c';
				break;
			case 'l':
				if(upper[y*length+x][0]=='c')
					upper[y*length+x][0]='s';
				break;
			}
		}
		if(lose){
			if(upper[y*length+x][0]=='o'){
				upper[y*length+x][1]=change(under[y*length+x]);
			}
			if(upper[y*length+x][0]=='s')
				upper[y*length+x][1]='s';
			if(upper[y*length+x][0]=='c')
				upper[y*length+x][1]='+';
			zhankai(under,length,width);
		}
		if(sf(under,length,width,boom_count)==-1) {
            lose=0;
			printf("You lose\n");
			printf("Please \"Ctrl+C\" to exit");
		} else if(sf(under,length,width,boom_count)==1) {
            lose=0;
			printf("You win\n");
			printf("Please \"Ctrl+C\" to exit");
		}
        Sleep(50);
	}
    return 0;
}